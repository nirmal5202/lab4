﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCarInventory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblMake = New System.Windows.Forms.Label()
        Me.ttfrmCarInventory = New System.Windows.Forms.ToolTip(Me.components)
        Me.lblOutputMessageBox = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.cmbxMake = New System.Windows.Forms.ComboBox()
        Me.txtModelInput = New System.Windows.Forms.TextBox()
        Me.txtPriceInput = New System.Windows.Forms.TextBox()
        Me.cmbxYear = New System.Windows.Forms.ComboBox()
        Me.chkbxNew = New System.Windows.Forms.CheckBox()
        Me.lblModel = New System.Windows.Forms.Label()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.lvCarInventory = New System.Windows.Forms.ListView()
        Me.columnNew = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnId = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnMake = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnModel = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.columnPrice = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SuspendLayout()
        '
        'lblMake
        '
        Me.lblMake.Location = New System.Drawing.Point(40, 22)
        Me.lblMake.Name = "lblMake"
        Me.lblMake.Size = New System.Drawing.Size(93, 40)
        Me.lblMake.TabIndex = 0
        Me.lblMake.Text = "&Make:"
        Me.lblMake.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblOutputMessageBox
        '
        Me.lblOutputMessageBox.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblOutputMessageBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputMessageBox.Location = New System.Drawing.Point(12, 566)
        Me.lblOutputMessageBox.Name = "lblOutputMessageBox"
        Me.lblOutputMessageBox.Size = New System.Drawing.Size(717, 170)
        Me.lblOutputMessageBox.TabIndex = 6
        Me.lblOutputMessageBox.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ttfrmCarInventory.SetToolTip(Me.lblOutputMessageBox, "Displays error if any")
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(306, 747)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(137, 40)
        Me.btnEnter.TabIndex = 7
        Me.btnEnter.Text = "&Enter"
        Me.ttfrmCarInventory.SetToolTip(Me.btnEnter, "Enter")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(449, 747)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(137, 40)
        Me.btnReset.TabIndex = 8
        Me.btnReset.Text = "&Reset"
        Me.ttfrmCarInventory.SetToolTip(Me.btnReset, "Reset All input fields")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(592, 747)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(137, 40)
        Me.btnExit.TabIndex = 9
        Me.btnExit.Text = "E&xit"
        Me.ttfrmCarInventory.SetToolTip(Me.btnExit, "Exit the Application")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'cmbxMake
        '
        Me.cmbxMake.FormattingEnabled = True
        Me.cmbxMake.Items.AddRange(New Object() {"Audi", "BMW", "Bugatti", "Cadillac", "Dodge", "Ford", "GMC", "Honda", "Hyundai", "Jaguar", "Kia", "Lamborghini", "Lexus", "Maserati", "Mazda", "Nissan", "Porsche", "Pontiac", "Royal", "Subaru", "Tesla", "Toyota", "Volkswagen"})
        Me.cmbxMake.Location = New System.Drawing.Point(139, 27)
        Me.cmbxMake.Name = "cmbxMake"
        Me.cmbxMake.Size = New System.Drawing.Size(243, 32)
        Me.cmbxMake.TabIndex = 10
        Me.ttfrmCarInventory.SetToolTip(Me.cmbxMake, "Dropdown list to select Make")
        '
        'txtModelInput
        '
        Me.txtModelInput.Location = New System.Drawing.Point(139, 64)
        Me.txtModelInput.Multiline = True
        Me.txtModelInput.Name = "txtModelInput"
        Me.txtModelInput.Size = New System.Drawing.Size(243, 35)
        Me.txtModelInput.TabIndex = 11
        Me.ttfrmCarInventory.SetToolTip(Me.txtModelInput, "Enter model name here")
        '
        'txtPriceInput
        '
        Me.txtPriceInput.Location = New System.Drawing.Point(139, 147)
        Me.txtPriceInput.Multiline = True
        Me.txtPriceInput.Name = "txtPriceInput"
        Me.txtPriceInput.Size = New System.Drawing.Size(243, 35)
        Me.txtPriceInput.TabIndex = 13
        Me.ttfrmCarInventory.SetToolTip(Me.txtPriceInput, "Enter price here")
        '
        'cmbxYear
        '
        Me.cmbxYear.FormattingEnabled = True
        Me.cmbxYear.Items.AddRange(New Object() {"1920", "1921", "1922", "1923", "1924", "1925", "1926", "1927", "1928", "1929", "1930", "1931", "1932", "1933", "1934", "1935", "1936", "1937", "1938", "1939", "1940", "1941", "1942", "1943", "1944", "1945", "1946", "1947", "1948", "1949", "1950", "1951", "1952", "1953", "1954", "1955", "1956", "1957", "1958", "1959", "1960", "1961", "1962", "1963", "1964", "1965", "1966", "1967", "1968", "1969", "1970", "1971", "1972", "1973", "1974", "1975", "1976", "1977", "1978", "1979", "1980", "1981", "1882", "1983", "1984", "1985", "1986", "1987", "1988", "1989", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020"})
        Me.cmbxYear.Location = New System.Drawing.Point(139, 107)
        Me.cmbxYear.Name = "cmbxYear"
        Me.cmbxYear.Size = New System.Drawing.Size(243, 32)
        Me.cmbxYear.TabIndex = 12
        Me.ttfrmCarInventory.SetToolTip(Me.cmbxYear, "Dropdown list to select Year")
        '
        'chkbxNew
        '
        Me.chkbxNew.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.chkbxNew.Location = New System.Drawing.Point(45, 188)
        Me.chkbxNew.Name = "chkbxNew"
        Me.chkbxNew.Size = New System.Drawing.Size(139, 38)
        Me.chkbxNew.TabIndex = 14
        Me.chkbxNew.Text = "&New:"
        Me.ttfrmCarInventory.SetToolTip(Me.chkbxNew, "Only check if the car is New")
        Me.chkbxNew.UseVisualStyleBackColor = True
        '
        'lblModel
        '
        Me.lblModel.Location = New System.Drawing.Point(40, 62)
        Me.lblModel.Name = "lblModel"
        Me.lblModel.Size = New System.Drawing.Size(93, 40)
        Me.lblModel.TabIndex = 1
        Me.lblModel.Text = "Model:"
        Me.lblModel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblYear
        '
        Me.lblYear.Location = New System.Drawing.Point(40, 102)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(93, 40)
        Me.lblYear.TabIndex = 2
        Me.lblYear.Text = "&Year:"
        Me.lblYear.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblPrice
        '
        Me.lblPrice.Location = New System.Drawing.Point(40, 142)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(93, 40)
        Me.lblPrice.TabIndex = 3
        Me.lblPrice.Text = "&Price:"
        Me.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lvCarInventory
        '
        Me.lvCarInventory.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.columnNew, Me.columnId, Me.columnMake, Me.columnModel, Me.columnYear, Me.columnPrice})
        Me.lvCarInventory.FullRowSelect = True
        Me.lvCarInventory.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvCarInventory.HideSelection = False
        Me.lvCarInventory.Location = New System.Drawing.Point(12, 229)
        Me.lvCarInventory.MultiSelect = False
        Me.lvCarInventory.Name = "lvCarInventory"
        Me.lvCarInventory.Size = New System.Drawing.Size(717, 334)
        Me.lvCarInventory.TabIndex = 5
        Me.lvCarInventory.UseCompatibleStateImageBehavior = False
        Me.lvCarInventory.View = System.Windows.Forms.View.Details
        '
        'columnNew
        '
        Me.columnNew.Text = "New"
        Me.columnNew.Width = 41
        '
        'columnId
        '
        Me.columnId.Text = "ID"
        Me.columnId.Width = 53
        '
        'columnMake
        '
        Me.columnMake.Text = "Make"
        Me.columnMake.Width = 81
        '
        'columnModel
        '
        Me.columnModel.Text = "Model"
        Me.columnModel.Width = 91
        '
        'columnYear
        '
        Me.columnYear.Text = "Year"
        Me.columnYear.Width = 67
        '
        'columnPrice
        '
        Me.columnPrice.Text = "Price"
        Me.columnPrice.Width = 75
        '
        'frmCarInventory
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ClientSize = New System.Drawing.Size(744, 796)
        Me.Controls.Add(Me.chkbxNew)
        Me.Controls.Add(Me.txtPriceInput)
        Me.Controls.Add(Me.cmbxYear)
        Me.Controls.Add(Me.txtModelInput)
        Me.Controls.Add(Me.cmbxMake)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lblOutputMessageBox)
        Me.Controls.Add(Me.lvCarInventory)
        Me.Controls.Add(Me.lblPrice)
        Me.Controls.Add(Me.lblYear)
        Me.Controls.Add(Me.lblModel)
        Me.Controls.Add(Me.lblMake)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmCarInventory"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Car Inventory"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblMake As Label
    Friend WithEvents ttfrmCarInventory As ToolTip
    Friend WithEvents lblModel As Label
    Friend WithEvents lblYear As Label
    Friend WithEvents lblPrice As Label
    Friend WithEvents lvCarInventory As ListView
    Friend WithEvents columnNew As ColumnHeader
    Friend WithEvents columnId As ColumnHeader
    Friend WithEvents columnMake As ColumnHeader
    Friend WithEvents columnModel As ColumnHeader
    Friend WithEvents columnYear As ColumnHeader
    Friend WithEvents columnPrice As ColumnHeader
    Friend WithEvents lblOutputMessageBox As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents cmbxMake As ComboBox
    Friend WithEvents txtModelInput As TextBox
    Friend WithEvents txtPriceInput As TextBox
    Friend WithEvents cmbxYear As ComboBox
    Friend WithEvents chkbxNew As CheckBox
End Class
