﻿Option Strict On
' Name: Nirmal Patel
' SID: 100767993
' Date: 18 July, 2020
' Lab 4
' Purpose: This lab is a window form application that is helpful to car seller to keep the record of cars.

Public Class frmCarInventory

#Region "Declarations"
    Const MIN_PRICE As Integer = 0  ' constant declared

    Dim CARs As New List(Of car)    ' new created CARs is added to list of car
    Dim listOfCars As New SortedList    ' declare a sorted list sorted list
    Dim editMode As Boolean = False     ' declare a boolean and set value of false as default
    Dim currentIndex As Integer = -1    ' declare an Integer with -1 of default value
    Dim changingNewData As Boolean = False  ' declare a boolean for changing data and set false as default value

    Private idCount As String = String.Empty    ' declare an empty string as private
#End Region

#Region "Buttons"
    ''' <summary>
    ''' Handles Exit button event
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        ' exit the application
        Application.Exit()
    End Sub

    ''' <summary>
    ''' Handles Reset button event
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ' reset all fields (created a function)
        ResetAllFields()
    End Sub

    ''' <summary>
    ''' Handles Enter button event
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        Dim inputMake As String = cmbxMake.Text     ' declare a string and give it the value of Make combo box
        Dim inputModel As String = txtModelInput.Text   ' declare a string and give it the value of Model input text box
        Dim inputYear As String = cmbxYear.Text     ' declare a string and give it the value of Make combo box
        Dim inputPrice As String = txtPriceInput.Text   ' delcare a string and give it the value of price input text box
        Dim inputNew As Boolean = chkbxNew.Checked  ' declare a boolean and give it the value of New check box

        ' declare a string and check if the input is valid or not (i have used a function to validate input)
        Dim errors As String = ValidateInputs(cmbxMake.ToString(), inputModel, cmbxYear.ToString(), inputPrice)
        Dim CAR As car  ' declare a variable that represents car.vb class

        ' check for errors if any
        If (String.IsNullOrEmpty(errors)) Then

            ' if the user edits existing data in list view
            If (editMode = True) Then

                CARs(currentIndex).makeInCarMethods = inputMake
                CARs(currentIndex).modelInCarMethods = inputModel
                CARs(currentIndex).yearInCarMethods = inputYear
                CARs(currentIndex).priceInCarMethods = inputPrice

                UpdateCarInventoryList()    ' call a function and complete
                ResetAllFields()    ' call a function to reset all input fields

                lblOutputMessageBox.Text = "Updated data"   ' display a message in appropriate label

            Else

                CAR = New car(inputMake, inputModel, inputYear, inputPrice, inputNew)   ' new data is created
                CARs.Add(CAR)
                ResetAllFields()    ' call a function to reset all input fields

                lblOutputMessageBox.Text = "Added new car!" ' display a message in appropriate label
                UpdateCarInventoryList()    ' call a function and complete

            End If
        Else
            'display the errors in the appropriate label
            lblOutputMessageBox.Text = errors
        End If
    End Sub

    ''' <summary>
    ''' Handles list view index selection and modifying
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub lvCarInventory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvCarInventory.SelectedIndexChanged

        Dim carVar As car   ' declare a variable that represents car.vb class

        'if listview is changed
        If (Not lvCarInventory.FocusedItem Is Nothing) Then

            currentIndex = lvCarInventory.FocusedItem.Index
            carVar = CARs(currentIndex)

            editMode = True ' set editMode to true

            cmbxMake.Text = carVar.makeInCarMethods
            txtModelInput.Text = carVar.modelInCarMethods
            txtPriceInput.Text = carVar.priceInCarMethods.ToString
            cmbxYear.Text = carVar.yearInCarMethods.ToString
            chkbxNew.Checked = CBool(carVar.idInCarMethods.ToString)

            ' display a message showing success
            lblOutputMessageBox.Text = "Data updated successfully"

        End If

    End Sub

    ''' <summary>
    ''' Handles list view item check
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub lvCarInventory_ItemCheck(sender As Object, e As ItemCheckEventArgs) Handles lvCarInventory.ItemCheck
        If (editMode = False) Then
            e.NewValue = e.CurrentValue
        End If
    End Sub
#End Region

#Region "Functions/Methods"

    ''' <summary>
    ''' Function that controls ResetAllFields
    ''' </summary>
    Private Sub ResetAllFields()

        txtModelInput.Text = String.Empty   ' reset Model text box value
        txtPriceInput.Text = String.Empty   ' reset Price text box value

        lblOutputMessageBox.Text = String.Empty ' reset output label value

        chkbxNew.Checked = False    ' uncheck New check box

        cmbxMake.SelectedIndex = -1 ' unselect combo box value
        cmbxYear.SelectedIndex = -1 ' unselect combo box value

        cmbxMake.Select()   ' select Make combo box

    End Sub

    ''' <summary>
    ''' Function that validates all inputs
    ''' </summary>
    ''' <param name="cmbxMake"></param>
    ''' <param name="model"></param>
    ''' <param name="cmbxYear"></param>
    ''' <param name="price"></param>
    ''' <returns></returns>
    Function ValidateInputs(cmbxMake As String, model As String, cmbxYear As String, price As String) As String
        Dim message As String = String.Empty
        Dim validPrice As Integer

        ' if make combo box has blank spaces or left as blank
        If (String.IsNullOrEmpty(cmbxMake)) Then
            message += "Please select a valid make" & Environment.NewLine
        End If

        ' if model input has blank spaces or left as blank
        If (String.IsNullOrEmpty(model)) Then
            message += "Please enter a valid model name" & Environment.NewLine
        End If

        ' if price input has blank spaces or left as blank
        If (Integer.TryParse(price, validPrice)) Then
            ' if price is less than MIN_PRICE
            If (validPrice < MIN_PRICE) Then
                message += "Price must be greater than or equal to " & MIN_PRICE & Environment.NewLine
            End If
        Else
            message += "Please enter a valid price tag" & Environment.NewLine
        End If

        ' if year combo box has blank spaces or left as blank
        If (String.IsNullOrEmpty(cmbxYear)) Then
            message += "Please select a valid year" & Environment.NewLine
        End If

        ' return a message
        Return message

        lblOutputMessageBox.Text = message
    End Function

    ''' <summary>
    ''' Function that updates the list view
    ''' </summary>
    Private Sub UpdateCarInventoryList()
        Dim carInventoryListItem As ListViewItem

        changingNewData = True
        lvCarInventory.Items.Clear()

        For Each Car As car In CARs
            carInventoryListItem = New ListViewItem()

            carInventoryListItem.Checked = Car.newInCarMethods
            carInventoryListItem.SubItems.Add(Car.makeInCarMethods)
            carInventoryListItem.SubItems.Add(Car.modelInCarMethods)
            carInventoryListItem.SubItems.Add(Car.yearInCarMethods)
            carInventoryListItem.SubItems.Add(Car.priceInCarMethods)

            lvCarInventory.Items.Add(carInventoryListItem)
        Next
        changingNewData = False

    End Sub

#End Region

End Class