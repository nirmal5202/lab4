﻿Public Class car

#Region "Properties"

    Private carId As Integer = 0
    Private carMake As String = String.Empty
    Private carModel As String = String.Empty
    Private carYear As String = String.Empty
    Private carPrice As Integer = 0
    Private carNew As Boolean = False
    Private Shared carCount As Integer = 0
    Private inputMake As String
    Private inputModel As String
    Private inputYear As String
    Private inputPrice As String
    Private inputNew As Boolean

#End Region

#Region "constructors"

    ''' <summary>
    ''' Create a new car profile using default values
    ''' </summary>
    Public Sub New()
        carCount += 1
        carId = carCount
    End Sub


    ''' <summary>
    ''' Create new car profile using provided values
    ''' </summary>
    ''' <param name="carMakeInPublic"></param>
    ''' <param name="carModelInPublic"></param>
    ''' <param name="carYearInPublic"></param>
    ''' <param name="carPriceInPublic"></param>
    ''' <param name="carNewInPublic"></param>
    Public Sub New(carMakeInPublic As String, carModelInPublic As String, carYearInPublic As String, carPriceInPublic As Integer, carNewInPublic As Boolean)
        carCount += 1
        carId = carCount
        Me.carMake = carMakeInPublic
        Me.carModel = carModelInPublic
        Me.carYear = carYearInPublic
        Me.carPrice = carPriceInPublic
        Me.carNew = carNewInPublic
    End Sub

    ''' <summary>
    ''' Default costructor
    ''' </summary>
    ''' <param name="inputMake"></param>
    ''' <param name="inputModel"></param>
    ''' <param name="inputYear"></param>
    ''' <param name="inputPrice"></param>
    ''' <param name="inputNew"></param>
    Public Sub New(inputMake As String, inputModel As String, inputYear As String, inputPrice As String, inputNew As Boolean)
        Me.inputMake = inputMake
        Me.inputModel = inputModel
        Me.inputYear = inputYear
        Me.inputPrice = inputPrice
        Me.inputNew = inputNew
    End Sub
#End Region

#Region "Methods"

    ''' <summary>
    ''' makeInCarMethods public property (get the car make value)
    ''' </summary>
    ''' <returns></returns>
    Public Property makeInCarMethods() As String
        Get
            Return carMake
        End Get
        Set(ByVal value As String)
            carMake = value
        End Set
    End Property

    ''' <summary>
    ''' modelInCarMethods public property (get the car model value)
    ''' </summary>
    ''' <returns></returns>
    Public Property modelInCarMethods() As String
        Get
            Return carModel
        End Get
        Set(ByVal value As String)
            carModel = value
        End Set
    End Property

    ''' <summary>
    ''' yearInCarMethods public property (get the car year value)
    ''' </summary>
    ''' <returns></returns>
    Public Property yearInCarMethods() As String
        Get
            Return carYear
        End Get
        Set(ByVal value As String)
            carYear = value
        End Set
    End Property

    ''' <summary>
    ''' priceInCarMethods public property (get the car price value)
    ''' </summary>
    ''' <returns></returns>
    Public Property priceInCarMethods() As String
        Get
            Return carPrice
        End Get
        Set(ByVal value As String)
            carPrice = value
        End Set
    End Property

    ''' <summary>
    ''' newInCarMethods public property (get the car status value, whether is it new or used)
    ''' </summary>
    ''' <returns></returns>
    Public Property newInCarMethods() As Boolean
        Get
            Return carNew
        End Get
        Set(ByVal value As Boolean)
            carNew = value
        End Set
    End Property

    ''' <summary>
    ''' countInCarMethods readOnly property (get the car count value)
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property countInCarMethods() As Double
        Get
            Return carCount
        End Get
    End Property

    ''' <summary>
    ''' idInCarMethods ReadOnly property (get the car id value)
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property idInCarMethods() As Double
        Get
            Return carId
        End Get
    End Property

#End Region

End Class
